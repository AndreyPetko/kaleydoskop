@extends('site.layout')


@section('content')


<div class="disabled-product">
    Товар не найден
</div>

@stop