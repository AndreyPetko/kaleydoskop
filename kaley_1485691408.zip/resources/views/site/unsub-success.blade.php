@extends('site.layout')


@section('content')

<div class="message">
	Вы успешно отписались от рассылки
</div>
<div class="to-main-page">
	<a href="/">На главную</a>
</div>



@stop