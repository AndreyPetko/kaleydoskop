{!!$emailMessage!!}
<br>
<br>
<br>
<a href="http://kaley.com/unsubscribe/{{$sub_id}}">Отписаться от рассылки</a>