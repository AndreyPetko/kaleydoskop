@extends('admin.layouts.admin')


@section('content')

<div class="success">
	{{$message}}

<div class="go-home">
	<a href="/admin">На главную</a>
</div>
</div>


@stop